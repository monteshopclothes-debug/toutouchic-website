// Netlify Function: keeps track of which time slots are already booked,
// per day, so one slot can't be booked twice — and blocks the FULL
// duration of an appointment (a dog grooming takes ~2 hours), not just
// its exact start time, so two bookings can't overlap.
// Storage: Netlify Blobs (same zero-setup store as blocked-dates.js).
//
// GET  /api/bookings?date=YYYY-MM-DD
//   -> { times: ["10:00", "10:30", "11:00", "11:30"] }
//      every 30-minute slot that is occupied by an existing booking
//      (public — only the taken times, never the customer's name/phone)
//
// POST /api/bookings  (normal customer booking, no password)
//   body: { date, time, durationSlots, name, phone, animal, service, pet }
//   durationSlots = how many consecutive 30-minute slots this appointment
//   needs (e.g. 4 = 2 hours). Defaults to 1 if not given.
//   -> 200 { ok: true }               slot(s) reserved
//   -> 409 { error: "slot_taken" }    overlaps an existing booking
//
// POST /api/bookings  (owner/admin actions, require ADMIN_PASSWORD)
//   body: { adminPassword, action: "admin_block", date, time, durationSlots, note? }
//     -> 200 { ok: true }             owner-blocked slot added
//     -> 409 { error: "slot_taken" }  overlaps an existing booking/block
//   body: { adminPassword, action: "admin_unblock", date, time }
//     -> 200 { ok: true }             removes that owner-added block only
//     -> 404 { error: "not_found" }   nothing to remove there
//   body: { adminPassword, action: "list_admin_blocks" }
//     -> 200 { blocks: [{ date, time, durationSlots }, ...] }  every
//        owner-blocked slot from today onward, across all dates
//   -> 401 { error: "wrong_password" } for any admin action with a bad password

const { getStore } = require('@netlify/blobs');

// Same default password as blocked-dates.js — override both by setting
// ADMIN_PASSWORD in Netlify's environment variables.
const DEFAULT_ADMIN_PASSWORD = 'Sharon55';
const STORE_NAME = 'toutouchic-bookings';
const SLOT_MINUTES = 30;
const MAX_DURATION_SLOTS = 8; // 4 hours, a generous safety cap

function isValidDate(d) {
  return typeof d === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(d);
}
function isValidTime(t) {
  return typeof t === 'string' && /^([01]\d|2[0-3]):[0-5]\d$/.test(t);
}
function timeToMinutes(t) {
  const [h, m] = t.split(':').map(Number);
  return h * 60 + m;
}
function minutesToTime(mins) {
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
}
function normalizeDuration(d) {
  const n = Number.isInteger(d) ? d : 1;
  return Math.min(Math.max(n, 1), MAX_DURATION_SLOTS);
}
/** Every 30-minute slot a booking of `durationSlots` starting at `time` occupies. */
function expandOccupied(time, durationSlots) {
  const startMin = timeToMinutes(time);
  const out = [];
  for (let i = 0; i < durationSlots; i++) {
    out.push(minutesToTime(startMin + i * SLOT_MINUTES));
  }
  return out;
}
/** Union of occupied slots across every existing booking for that day. */
function allOccupiedTimes(record) {
  const set = new Set();
  Object.entries(record.slots || {}).forEach(([time, booking]) => {
    expandOccupied(time, normalizeDuration(booking.durationSlots)).forEach((t) => set.add(t));
  });
  return set;
}

exports.handler = async (event) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json',
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 204, headers, body: '' };
  }

  const store = getStore(STORE_NAME);

  if (event.httpMethod === 'GET') {
    const date = (event.queryStringParameters || {}).date;
    if (!isValidDate(date)) {
      return { statusCode: 400, headers, body: JSON.stringify({ error: 'invalid_date' }) };
    }
    const record = (await store.get(date, { type: 'json' })) || { slots: {} };
    const occupied = Array.from(allOccupiedTimes(record)).sort();
    return { statusCode: 200, headers, body: JSON.stringify({ times: occupied }) };
  }

  if (event.httpMethod === 'POST') {
    let payload;
    try {
      payload = JSON.parse(event.body || '{}');
    } catch (e) {
      return { statusCode: 400, headers, body: JSON.stringify({ error: 'invalid_json' }) };
    }

    const action = payload.action;
    const isAdminAction = action === 'admin_block' || action === 'admin_unblock' || action === 'list_admin_blocks';

    if (isAdminAction) {
      const adminPassword = process.env.ADMIN_PASSWORD || DEFAULT_ADMIN_PASSWORD;
      if (payload.adminPassword !== adminPassword) {
        return { statusCode: 401, headers, body: JSON.stringify({ error: 'wrong_password' }) };
      }

      if (action === 'list_admin_blocks') {
        const blocks = [];
        try {
          const { blobs } = await store.list();
          const todayStr = new Date().toISOString().slice(0, 10);
          for (const b of blobs) {
            if (b.key < todayStr) continue; // skip past dates
            const rec = await store.get(b.key, { type: 'json' });
            if (!rec || !rec.slots) continue;
            Object.entries(rec.slots).forEach(([time, booking]) => {
              if (booking.adminBlocked) {
                blocks.push({ date: b.key, time, durationSlots: normalizeDuration(booking.durationSlots) });
              }
            });
          }
        } catch (e) {
          // store.list() unsupported or failed: return what we have (empty)
        }
        blocks.sort((a, b) => (a.date + a.time).localeCompare(b.date + b.time));
        return { statusCode: 200, headers, body: JSON.stringify({ blocks }) };
      }

      const { date, time } = payload;
      if (!isValidDate(date) || !isValidTime(time)) {
        return { statusCode: 400, headers, body: JSON.stringify({ error: 'invalid_input' }) };
      }

      const record = (await store.get(date, { type: 'json' })) || { slots: {} };
      if (!record.slots) record.slots = {};

      if (action === 'admin_block') {
        const durationSlots = normalizeDuration(payload.durationSlots);
        const alreadyOccupied = allOccupiedTimes(record);
        const candidate = expandOccupied(time, durationSlots);
        if (candidate.some((t) => alreadyOccupied.has(t))) {
          return { statusCode: 409, headers, body: JSON.stringify({ error: 'slot_taken' }) };
        }
        record.slots[time] = {
          durationSlots,
          adminBlocked: true,
          note: payload.note || '',
          bookedAt: new Date().toISOString(),
        };
        await store.setJSON(date, record);
        return { statusCode: 200, headers, body: JSON.stringify({ ok: true }) };
      }

      if (action === 'admin_unblock') {
        const existing = record.slots[time];
        if (!existing || !existing.adminBlocked) {
          // Only ever removes an owner-added block, never a real customer booking.
          return { statusCode: 404, headers, body: JSON.stringify({ error: 'not_found' }) };
        }
        delete record.slots[time];
        await store.setJSON(date, record);
        return { statusCode: 200, headers, body: JSON.stringify({ ok: true }) };
      }
    }

    // ---- normal customer booking (no password) ----
    const { date, time, name, phone, animal, service, pet, photoUrl } = payload;
    const durationSlots = normalizeDuration(payload.durationSlots);
    if (!isValidDate(date) || !isValidTime(time)) {
      return { statusCode: 400, headers, body: JSON.stringify({ error: 'invalid_input' }) };
    }

    const record = (await store.get(date, { type: 'json' })) || { slots: {} };
    if (!record.slots) record.slots = {};

    const alreadyOccupied = allOccupiedTimes(record);
    const candidate = expandOccupied(time, durationSlots);

    // Reject if this appointment's duration would overlap any existing one.
    if (candidate.some((t) => alreadyOccupied.has(t))) {
      return { statusCode: 409, headers, body: JSON.stringify({ error: 'slot_taken' }) };
    }

    record.slots[time] = {
      durationSlots,
      name: name || '',
      phone: phone || '',
      animal: animal || '',
      service: service || '',
      pet: pet || '',
      photoUrl: photoUrl || '',
      bookedAt: new Date().toISOString(),
    };

    await store.setJSON(date, record);

    return { statusCode: 200, headers, body: JSON.stringify({ ok: true }) };
  }

  return { statusCode: 405, headers, body: JSON.stringify({ error: 'method_not_allowed' }) };
};
