// Netlify Function: stores a customer-uploaded photo (of their dog) and
// serves it back by id, so a link to it can be included in the
// WhatsApp confirmation message sent to the salon.
// Storage: Netlify Blobs (same store family as the other functions).
//
// POST /api/photo
//   body: { imageBase64, contentType }   (imageBase64 has NO "data:" prefix)
//   -> 200 { id, url }
//
// GET  /api/photo?id=<id>
//   -> the raw image bytes, with the right Content-Type

const { getStore } = require('@netlify/blobs');
const crypto = require('crypto');

const STORE_NAME = 'toutouchic-photos';
const MAX_BASE64_CHARS = 8 * 1024 * 1024; // ~6MB raw image, generous safety cap

exports.handler = async (event) => {
  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 204, headers: corsHeaders, body: '' };
  }

  const store = getStore(STORE_NAME);

  if (event.httpMethod === 'GET') {
    const id = (event.queryStringParameters || {}).id;
    if (!id || !/^[a-f0-9]{32}$/.test(id)) {
      return { statusCode: 400, headers: { ...corsHeaders, 'Content-Type': 'text/plain' }, body: 'invalid id' };
    }
    const record = await store.get(id, { type: 'json' });
    if (!record) {
      return { statusCode: 404, headers: { ...corsHeaders, 'Content-Type': 'text/plain' }, body: 'not found' };
    }
    return {
      statusCode: 200,
      headers: {
        ...corsHeaders,
        'Content-Type': record.contentType || 'image/jpeg',
        'Cache-Control': 'public, max-age=31536000, immutable',
      },
      body: record.data,
      isBase64Encoded: true,
    };
  }

  if (event.httpMethod === 'POST') {
    let payload;
    try {
      payload = JSON.parse(event.body || '{}');
    } catch (e) {
      return { statusCode: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' }, body: JSON.stringify({ error: 'invalid_json' }) };
    }

    const { imageBase64, contentType } = payload;
    if (!imageBase64 || typeof imageBase64 !== 'string') {
      return { statusCode: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' }, body: JSON.stringify({ error: 'missing_image' }) };
    }
    if (imageBase64.length > MAX_BASE64_CHARS) {
      return { statusCode: 413, headers: { ...corsHeaders, 'Content-Type': 'application/json' }, body: JSON.stringify({ error: 'image_too_large' }) };
    }

    const id = crypto.randomBytes(16).toString('hex');
    await store.setJSON(id, {
      data: imageBase64,
      contentType: contentType && /^image\//.test(contentType) ? contentType : 'image/jpeg',
      uploadedAt: new Date().toISOString(),
    });

    return {
      statusCode: 200,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      body: JSON.stringify({ id, url: `/api/photo?id=${id}` }),
    };
  }

  return { statusCode: 405, headers: { ...corsHeaders, 'Content-Type': 'application/json' }, body: JSON.stringify({ error: 'method_not_allowed' }) };
};
