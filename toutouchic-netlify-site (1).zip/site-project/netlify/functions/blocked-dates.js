// Netlify Function: manages the salon's owner-blocked dates.
// Storage: Netlify Blobs (zero extra setup, works automatically once
// this site is deployed on Netlify — no external database needed).
//
// GET  /api/blocked-dates
//   -> { dates: ["2026-10-05", ...] }   (public, read-only, no password)
//
// POST /api/blocked-dates
//   body: { password, action: "check" }
//     -> 200 if password correct, 401 if not (used by the admin login form)
//   body: { password, action: "add"|"remove", date: "YYYY-MM-DD" }
//     -> { dates: [...] } updated list, 401 if password wrong
//
// The password defaults to "Sharon55" so this works right out of the box.
// To change it, set an ADMIN_PASSWORD environment variable in Netlify
// (Site settings -> Environment variables) — that value then overrides
// this default automatically.

const { getStore } = require('@netlify/blobs');

const DEFAULT_ADMIN_PASSWORD = 'Sharon55';
const STORE_NAME = 'toutouchic-settings';
const KEY = 'blocked-dates';

exports.handler = async (event) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json',
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 204, headers, body: '' };
  }

  const store = getStore(STORE_NAME);

  if (event.httpMethod === 'GET') {
    const raw = await store.get(KEY, { type: 'json' });
    const dates = Array.isArray(raw) ? raw : [];
    return { statusCode: 200, headers, body: JSON.stringify({ dates }) };
  }

  if (event.httpMethod === 'POST') {
    let payload;
    try {
      payload = JSON.parse(event.body || '{}');
    } catch (e) {
      return { statusCode: 400, headers, body: JSON.stringify({ error: 'invalid_json' }) };
    }

    const { password, action, date } = payload;
    const adminPassword = process.env.ADMIN_PASSWORD || DEFAULT_ADMIN_PASSWORD;

    if (password !== adminPassword) {
      return { statusCode: 401, headers, body: JSON.stringify({ error: 'wrong_password' }) };
    }

    if (action === 'check') {
      return { statusCode: 200, headers, body: JSON.stringify({ ok: true }) };
    }

    if (!date || !/^\d{4}-\d{2}-\d{2}$/.test(date)) {
      return { statusCode: 400, headers, body: JSON.stringify({ error: 'invalid_date' }) };
    }

    const raw = await store.get(KEY, { type: 'json' });
    let dates = Array.isArray(raw) ? raw : [];

    if (action === 'add') {
      if (!dates.includes(date)) dates.push(date);
    } else if (action === 'remove') {
      dates = dates.filter((d) => d !== date);
    } else {
      return { statusCode: 400, headers, body: JSON.stringify({ error: 'invalid_action' }) };
    }

    dates.sort();
    await store.setJSON(KEY, dates);

    return { statusCode: 200, headers, body: JSON.stringify({ dates }) };
  }

  return { statusCode: 405, headers, body: JSON.stringify({ error: 'method_not_allowed' }) };
};
