# TouTouChic website — deployen op Netlify

Deze map bevat de volledige site + een klein back-end functie zodat Sharon
zelf dagen kan blokkeren (bv. vakantie, ziekte) — zichtbaar voor elke
bezoeker, meteen.

Daarnaast onthoudt de site ook welke uren al geboekt zijn: zodra iemand
een tijdstip bevestigt, verdwijnt dat uur meteen als optie voor de
volgende bezoeker op diezelfde dag.

Sharon kan vanuit hetzelfde beheerscherm ook een los tijdslot blokkeren
(bv. "14 november 14u, want dan zit ik vol" of een eigen afspraak) zonder
er meteen de hele dag voor te moeten sluiten.

Bij een boeking kan de klant optioneel een foto van het huisdier
toevoegen — die foto wordt mee opgeslagen en er komt een link naar in het
WhatsApp-bericht dat Sharon ontvangt.

**Beheerderswachtwoord: `Sharon55`** — dat werkt meteen na deployen,
zonder dat je iets moet instellen (zie Stap 3 hieronder om dat te
wijzigen).

## Wat zit er in deze map?
- `index.html` — de volledige website (NL/FR, booking-flow, beheerscherm)
- `netlify/functions/blocked-dates.js` — bewaart de dagen die Sharon blokkeert
  (via Netlify Blobs, geen apart account/database nodig)
- `netlify/functions/bookings.js` — bewaart per dag welke uren al geboekt of
  handmatig geblokkeerd zijn, zodat een tijdstip maar één keer uitgedeeld wordt
- `netlify/functions/photo.js` — bewaart de geüploade hondenfoto's en geeft
  er een link naar terug
- `netlify.toml` — Netlify-configuratie
- `package.json` — de ene dependency die de functies nodig hebben

## Stap 1 — installeer de dependency
Open een terminal in deze map en voer uit:

```
npm install
```

## Stap 2 — deploy naar Netlify
De makkelijkste manier:

1. Zet deze map in een GitHub-repository (of gebruik `netlify deploy` met de Netlify CLI).
2. Ga naar [app.netlify.com](https://app.netlify.com) → **Add new site** → **Import an existing project** (bij een GitHub-repo) — Netlify herkent `netlify.toml` automatisch en installeert de dependency zelf.
   - Werk je liever met "drag & drop" deploy? Run dan eerst lokaal `npm install`, zodat de map `node_modules` erbij zit, en sleep de hele map naar het Netlify-dashboard.

## Stap 3 — beheerderswachtwoord (optioneel te wijzigen)
Het wachtwoord staat standaard op `Sharon55` — dat werkt direct, geen
verdere actie nodig. Wil je een ander wachtwoord instellen:
1. Ga in Netlify naar **Site settings → Environment variables**.
2. Voeg een variabele toe: `ADMIN_PASSWORD` = het gewenste wachtwoord.
   Zolang die variabele niet bestaat, blijft `Sharon55` gelden.
3. Ga naar **Deploys** → **Trigger deploy** → **Deploy site** zodat de functie de nieuwe variabele meekrijgt.

## Stap 4 — beheerscherm gebruiken
Sharon surft naar:

```
https://JOUWSITE.netlify.app/#beheer
```

(de link staat ook onderaan de site, bij "Beheerder"/"Gestion" in de footer)

Daar logt ze in met het wachtwoord en kan ze:
- een hele datum kiezen en blokkeren ("Dag blokkeren") of weer vrijgeven
- een los tijdslot blokkeren ("Blokkeer een tijdslot"): datum + uur + duur
  kiezen (30 min tot 3 uur) en op "Tijdslot blokkeren" klikken; onderaan
  ziet ze een lijst van alle geblokkeerde tijdsloten met een
  "Vrijgeven"-knop per slot

Zodra ze iets blokkeert (dag of tijdslot), ziet elke bezoeker die daarna
een afspraak probeert te boeken dat meteen — zonder dat jij iets moet
aanpassen in de code. Een tijdslot dat al door een klant geboekt is, kan
ze vanuit dit scherm niet per ongeluk verwijderen (dat kan alleen via het
tijdslot zelf, en enkel als het een eigen blokkade was, geen klantboeking).

## Werkt dit ook lokaal getest (zonder Netlify)?
Nee — de functies draaien alleen als de site via Netlify gehost wordt (of
via `netlify dev` lokaal). Open je gewoon `index.html` rechtstreeks in de
browser (dubbelklikken), dan werkt alles behalve het beheerscherm, de
live blokkering en het onthouden van geboekte uren; de vaste
sluitingsdagen (di/vr/zo) blijven wel werken, want die staan gewoon in
de HTML/JS zelf.

## Wie ziet de klantgegevens van een boeking?
`bookings.js` bewaart per geboekt uur ook de naam, telefoon, dier en
dienst (zodat dit later eventueel getoond kan worden aan Sharon). Dat is
niet zichtbaar op de site zelf — bezoekers zien enkel welke uren al
bezet zijn, nooit door wie. De boeking zelf komt bij Sharon terecht via
de WhatsApp-knop, zoals voorheen — nu met een link naar de foto van de
hond erbij.

## Nog één ding om zelf te overwegen
1. **Duur per hond** — Sharon zei dat de duur tussen 1u30 en 2u ligt,
   afhankelijk van het ras. De site toont die tekst nu zo, maar blokkeert
   voorlopig steeds de volle 2 uur per hondenafspraak (veiliger dan te
   weinig blokkeren). Als bepaalde rassen echt maar 1u30 nodig hebben en
   je dat wil benutten voor extra boekingen per dag, kan dat per ras
   ingesteld worden — laat maar weten.
